<?php
/**
 * CIC contact form handler (v4, 2026-11-22).
 * - Every valid request is saved to a private log FIRST, then emailed, so no lead is lost if mail fails.
 * - Spam guards: honeypot field, minimum fill time, per-IP rate limit.
 * - Works with the site form (name, phone, email, service, message, lang, ts, website) and redirects back
 *   to the page with ?sent=1#contact (or ?sent=0). Answers JSON when called with Accept: application/json.
 * Before uploading: keep a backup of the old contact.php on the server.
 */
declare(strict_types=1);

const TO_EMAIL   = 'cic@cic2030.com';           // where leads are sent
const FROM_EMAIL = 'noreply@cic2030.com';       // must be an address on this domain (Bluehost requirement)
const MIN_SECONDS = 3;                          // faster submissions are treated as bots
const MAX_PER_HOUR = 8;                         // per IP

// private storage: one level above the web root when writable, otherwise a locked folder inside it
$base = dirname(__DIR__) . '/cic-leads';
if (!is_dir($base) && !@mkdir($base, 0750, true)) { $base = __DIR__ . '/_leads'; @mkdir($base, 0750, true); }
if (strpos($base, __DIR__) === 0 && !file_exists("$base/.htaccess")) {
    @file_put_contents("$base/.htaccess", "Require all denied\nDeny from all\n");
    @file_put_contents("$base/index.html", '');
}

function field(string $k, int $max): string {
    $v = isset($_POST[$k]) && is_string($_POST[$k]) ? $_POST[$k] : '';
    $v = trim(str_replace(["\r", "\0"], '', $v));
    return mb_substr($v, 0, $max, 'UTF-8');
}
function one_line(string $s): string { return trim(preg_replace('/[\r\n\t]+/', ' ', $s)); }
function done(bool $ok, string $why = ''): void {
    $wantsJson = stripos($_SERVER['HTTP_ACCEPT'] ?? '', 'application/json') !== false;
    if ($wantsJson) { header('Content-Type: application/json; charset=utf-8'); echo json_encode(['ok' => $ok, 'error' => $why]); exit; }
    $back = '/';
    $ref = $_SERVER['HTTP_REFERER'] ?? '';
    $host = preg_replace('/:\d+$/', '', (string) ($_SERVER['HTTP_HOST'] ?? ''));
    if ($ref && parse_url($ref, PHP_URL_HOST) === $host) { $back = parse_url($ref, PHP_URL_PATH) ?: '/'; }
    if (!preg_match('~^/(?!/)~', $back) || strpbrk($back, "\\\r\n") !== false) { $back = '/'; }  // no protocol-relative or odd paths
    header('Location: ' . $back . '?sent=' . ($ok ? '1' : '0') . '#contact', true, 303);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') { header('Location: /#contact', true, 302); exit; }

// honeypot + timing: pretend success so bots learn nothing
if (field('website', 200) !== '') done(true);
$ts = (int) field('ts', 20);
if ($ts > 0) { $ts = $ts > 20000000000 ? intdiv($ts, 1000) : $ts; if (time() - $ts < MIN_SECONDS) done(true); }

$name    = one_line(field('name', 120));
$phone   = one_line(field('phone', 40));
$email   = one_line(field('email', 160));
$service = one_line(field('service', 120));
$message = field('message', 4000);
$lang    = preg_replace('/[^a-z]/', '', field('lang', 5)) ?: 'ar';

if ($name === '' || $message === '' || !preg_match('/^[0-9+()\-\s]{7,20}$/', $phone)) done(false, 'invalid');
if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) $email = '';

// rate limit per IP
$ip = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
$rl = "$base/rate-" . substr(hash('sha256', $ip . date('YmdH')), 0, 20);
$n = (int) @file_get_contents($rl);
if ($n >= MAX_PER_HOUR) done(false, 'rate');
@file_put_contents($rl, (string) ($n + 1), LOCK_EX);
if (mt_rand(1, 20) === 1) { foreach (glob("$base/rate-*") ?: [] as $f) { if (filemtime($f) < time() - 86400) @unlink($f); } }  // tidy old counters

// 1) save the lead
$lead = ['time' => date('c'), 'name' => $name, 'phone' => $phone, 'email' => $email, 'service' => $service,
         'message' => $message, 'lang' => $lang, 'page' => one_line((string) ($_SERVER['HTTP_REFERER'] ?? '')), 'ip' => $ip];
$saved = @file_put_contents("$base/leads-" . date('Y-m') . '.jsonl', json_encode($lead, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX) !== false;

// 2) email it
$subject = '=?UTF-8?B?' . base64_encode('طلب جديد من الموقع — ' . $name) . '?=';
$body = "طلب جديد من موقع cic2030.com\n\n"
      . "الاسم: $name\nالجوال: $phone\nالبريد: " . ($email ?: '-') . "\nالخدمة: " . ($service ?: '-') . "\nاللغة: $lang\n\n"
      . "التفاصيل:\n$message\n\n—\nالصفحة: {$lead['page']}\nالوقت: {$lead['time']}\n";
$headers = "From: CIC Website <" . FROM_EMAIL . ">\r\n"
         . ($email ? "Reply-To: $email\r\n" : '')
         . "MIME-Version: 1.0\r\nContent-Type: text/plain; charset=UTF-8\r\nContent-Transfer-Encoding: 8bit\r\n";
$mailed = @mail(TO_EMAIL, $subject, $body, $headers, '-f' . FROM_EMAIL);

done($saved || $mailed, ($saved || $mailed) ? '' : 'server');
